<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Experiences;
use App\Educations;
use App\Externallinks;
use App\Follows;
use App\Skills;
use App\Userskills;
use App\Feeds;
use App\Types;
use App\Catalogs;
use App\Feedskills;
use App\Comments;

class adminUserController extends Controller
{
    public function getAdminUser(){
        $profiles = User::all();
        return view('admin.usermanager',['profiles'=>$profiles]);
    }

    public function getDetailUser(){
        return view('admin.information');
    }
    public function getDetailUserInfo(){
        return view('admin.information');
    }
    public function getDetailUserPost(){
        return view ('admin.post');
    }
    public function getDetailUserExtanallink(){
        return view ('admin.extanallink');
    }
}
