<ul class="menu-detail-user">
    <li class="active"><a href="admin/detailuser/info">Thông tin tài khoản</a></li>
    <li><a href="admin/detailuser/post">Bài đăng</a></li>
    <li><a href="admin/detailuser/extanallink">Liên kết</a></li>
    <li><a href="#reviews">Người theo dõi</a></li>
    <li><a href="#reviews">Đang theo dõi</a></li>
    <li><a href="#reviews">Hình ảnh</a></li>
</ul>